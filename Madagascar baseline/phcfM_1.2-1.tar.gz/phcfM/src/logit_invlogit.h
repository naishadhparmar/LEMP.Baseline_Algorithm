// Prototype of functions logit and invlogit
double logit (double x);
double invlogit (double x);
